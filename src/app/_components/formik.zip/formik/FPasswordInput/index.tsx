import React, { memo, useState } from "react";

import { EyeFilledIcon } from "../../icons/EyeFilledIcon";
import { EyeSlashFilledIcon } from "../../icons/EyeSlashFilledIcon";
import TextInput, { MyInputProps } from "../FTextInput";

const PasswordInput = memo((props: MyInputProps) => {
  const [isVisible, setIsVisible] = useState(false);

  const toggleVisibility = () => setIsVisible(!isVisible);

  return (
    <TextInput
      {...props}
      endContent={
        <button
          className="h-[100%] focus:outline-none"
          type="button"
          onClick={toggleVisibility}
        >
          {isVisible ? <EyeSlashFilledIcon /> : <EyeFilledIcon />}
        </button>
      }
      type={isVisible ? "text" : "password"}
    />
  );
});

export default PasswordInput;
