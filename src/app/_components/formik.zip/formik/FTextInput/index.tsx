import React, { memo } from "react";

import { Divider, Input, InputProps } from "@nextui-org/react";

import { Field, FieldInputProps, FieldMetaProps, FormikProps } from "formik";

const DefaultClassNames = {
  // innerWrapper: "!items-center",
  inputWrapper:
    "bg-white border border-neutral-stroke-light rounded-lg group-data-[focus=true]:!border-brand-primary hover:!border-brand-primary active:!border-brand-primary !px-4 !py-2 font-gilroy !min-h-[60px] shadow-none",
  label: "text-neutral-element-secondary font-medium text-base font-gilroy",
  input: "font-gilroy font-medium text-base",
  errorMessage: "text-sm font-medium text-accent-error",
  helperWrapper: "!p-0",
};

export interface MyFieldProps {
  field: FieldInputProps<any>;
  form: FormikProps<any>;
  meta: FieldMetaProps<any>;
}

export interface MyInputProps extends InputProps {
  placeholder?: string;
  type?: string;
  name: string;
  className?: string;
  label?: string;
  isClear?: boolean;
  editable?: boolean;
  isDivider?: boolean;
}
const TextInput = memo(
  ({
    isClear = false,
    editable = true,
    isDivider = false,
    classNames = DefaultClassNames,
    ...props
  }: MyInputProps) => {
    return (
      <div>
        <Field name={props.name}>
          {({
            field, // { name, value, onChange, onBlur }
            // eslint-disable-next-line unused-imports/no-unused-vars
            form: { touched, errors, setFieldValue }, // also values, setXXXX, handleXXXX, dirty, isValid, status, etc.
            meta,
          }: MyFieldProps) => {
            if (!editable) {
              return (
                <div className="flex flex-col">
                  <p className="!text-base !font-medium text-neutral-element-secondary">
                    {props.label}
                  </p>
                  <p className="mt-1 leading-6">{field.value || "-"}</p>
                  {isDivider && <Divider className="mt-3" />}
                </div>
              );
            }

            return (
              <Input
                // isClearable={isClear}
                // {...(isClear
                //   ? { onClear: () => setFieldValue(props.name, "") }
                //   : {})}
                {...field}
                {...props}
                fullWidth
                autoComplete="new-password"
                color="primary"
                variant="bordered"
                classNames={classNames}
                isInvalid={!!(meta.touched && meta.error)}
                errorMessage={meta.error}
              />
            );
          }}
        </Field>
      </div>
    );
  },
);

export default TextInput;
