import React, { memo } from "react";

import { Divider, Select, SelectItem, SelectProps } from "@nextui-org/react";

import Text from "../../common/Text";
import ArrowDownIcon from "../../icons/ArrowDownIcon";

import { Field, FieldInputProps, FieldMetaProps, FormikProps } from "formik";

const classNames = {
  trigger:
    "bg-white border border-neutral-stroke-light hover:!bg-white hover:!border-brand-primary active:!border-brand-primary !px-4 !py-[8px] font-gilroy !h-[60px] shadow-none",
  label: "text-neutral-element-secondary font-medium text-base font-gilroy ",
  input: "font-gilroy font-medium text-lg leading-[18px]",
  errorMessage: "text-sm font-medium text-accent-error",
  innerWrapper: "group-data-[has-label=true]:!pt-0",
  listbox: "!px-0 !py-2 !rounded-lg",
  popoverContent: "!p-0 !rounded-lg",
  selectorIcon: "!size-5",
};

interface MyFieldProps {
  field: FieldInputProps<any>;
  form: FormikProps<any>;
  meta: FieldMetaProps<any>;
}

interface MyInputProps extends Omit<SelectProps, "children"> {
  placeholder?: string;
  type?: string;
  name: string;
  className?: string;
  label?: string;
  isClear?: boolean;
  editable?: boolean;
  isDivider?: boolean;
  options: any[];
  isRequired?: boolean;
}

function SelectInput({
  options,
  name,
  renderValue,
  editable = true,
  isDivider = false,
  isRequired = false,
  ...restProps
}: MyInputProps) {
  return (
    <div className="w-full">
      <Field name={name}>
        {({
          field, // { name, value, onChange, onBlur }
          // eslint-disable-next-line unused-imports/no-unused-vars
          form: { touched, errors, setFieldValue }, // also values, setXXXX, handleXXXX, dirty, isValid, status, etc.
          meta,
        }: MyFieldProps) => {
          if (!editable) {
            return (
              <div className="flex flex-col">
                <p className="leading-5 text-neutral-element-secondary">
                  {restProps.label}
                </p>
                <p className="mt-1 leading-6">
                  {options.find((item) => item.key === field?.value)?.label ||
                    "-"}
                </p>
                {isDivider && <Divider className="mt-2" />}
              </div>
            );
          }

          return (
            <Select
              isRequired={isRequired}
              label={restProps.label}
              fullWidth
              classNames={classNames}
              onChange={(e) => setFieldValue(name, e.target.value)}
              selectedKeys={new Set(field.value ? field.value?.split(",") : [])}
              isInvalid={!!(meta.touched && meta.error)}
              errorMessage={meta.error}
              selectorIcon={
                <div>
                  <ArrowDownIcon />
                </div>
              }
              listboxProps={{
                classNames: {
                  list: "max-h-[300px] overflow-y-auto overflow-x-hidden",
                },
              }}
              renderValue={
                renderValue
                  ? renderValue
                  : (items) => {
                      return (
                        <div className="row gap-3 pt-5">
                          {items.map((item: any) => {
                            return (
                              <Text variant="body2-regular" key={item.key}>
                                {item.textValue}
                              </Text>
                            );
                          })}
                        </div>
                      );
                    }
              }
            >
              {options.map((option) => (
                <SelectItem
                  key={option.key}
                  hideSelectedIcon
                  textValue={option.label}
                  className="!rounded-none data-[hover=true]:!bg-neutral-surface data-[selectable=true]:focus:!bg-brand-super-light"
                >
                  <div className="!px-4 !py-3">
                    <Text variant="body2-regular">{option.label}</Text>
                  </div>
                </SelectItem>
              ))}
            </Select>
          );
        }}
      </Field>
    </div>
  );
}

export default memo(SelectInput);
