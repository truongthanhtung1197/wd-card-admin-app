import React, { memo, ReactNode } from "react";

import CheckedIcon from "@/app/_components/icons/CheckedIcon";
import UnCheckIcon from "@/app/_components/icons/UnCheckIcon";
import { Button } from "@nextui-org/button";

interface MyCheckboxProps {
  className?: string;
  checked?: boolean;
  onChecked?: (checked: boolean) => void;
  UnCheckComponent?: ReactNode;
  isDisabled?: boolean;
}

function MyCheckbox({
  className = "",
  checked,
  onChecked,
  UnCheckComponent,
  isDisabled,
}: MyCheckboxProps) {
  return (
    <div className={className}>
      {checked ? (
        <Button
          className="!size-6 !min-w-6 rounded-none"
          isIconOnly
          radius="full"
          variant="light"
          size="sm"
          isDisabled={isDisabled}
          onClick={() => onChecked?.(false)}
        >
          <CheckedIcon />
        </Button>
      ) : UnCheckComponent ? (
        UnCheckComponent
      ) : (
        <Button
          className="!size-6 !min-w-6 rounded-none"
          isIconOnly
          radius="full"
          variant="light"
          size="sm"
          isDisabled={isDisabled}
          onClick={() => onChecked?.(true)}
        >
          <UnCheckIcon />
        </Button>
      )}
    </div>
  );
}

export default memo(MyCheckbox);
