import React, { memo, useCallback, useEffect, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";

import ArrowDownIcon from "@/app/_components/icons/ArrowDownIcon";
import CheckedIcon from "@/app/_components/icons/CheckedIcon";
import SearchIcon from "@/app/_components/icons/SearchIcon";
import UnCheckIcon from "@/app/_components/icons/UnCheckIcon";
import { cn } from "@/utils/common.util";
import { Input } from "@nextui-org/input";
import { Select, SelectItem, SelectSection } from "@nextui-org/react";

interface MyMultipleSelectProps {
  options: { label: string; key: string }[];
  showSearch?: boolean;
  param: string;
}

export const MyMultipleSelect: React.FC<MyMultipleSelectProps> = memo(
  ({ options, showSearch = false, param }) => {
    const searchParams = useSearchParams();
    const pathname = usePathname();
    const { push } = useRouter();

    const targetParam = searchParams.get(param) || "";
    const [selectedKeys, setSelectedKeys] = useState<Set<string>>(new Set([]));
    const [searchKeyword, setSearchKeyword] = useState("");

    const classNames = {
      trigger: `relative bg-white border hover:!border-brand-primary hover:!bg-white active:!border-brand-primary !pl-[16px] !py-2 font-gilroy !h-[40px] shadow-none rounded-3xl ${
        targetParam.toString() !== ""
          ? "border-neutral-element-tertiary"
          : "border-neutral-stroke-light"
      }`,
      label: "text-neutral-element-secondary font-medium text-lg font-gilroy ",
      input: "font-gilroy font-medium text-lg leading-[18px]",
      value: "text-neutral-element-primary font-medium text-base",
      listboxWrapper: "!px-0 !max-h-full !h-fit",
      content: "!px-0",
      listbox: "!px-0 !py-2 !rounded-none",
      popoverContent: `!max-w-[260px] !p-0 !rounded-lg w-max`,
    };

    const onSelect = useCallback(
      (e: any) => {
        const params = new URLSearchParams(searchParams);

        const listStatus = e.target.value ? e.target.value?.split(",") : [];
        setSelectedKeys(new Set(listStatus));
        params.set(param, e.target.value);
        params.set("page", "1");

        push(`${pathname}?${params.toString()}`);
      },
      [pathname, searchParams],
    );

    const onClearAll = useCallback(() => {
      const params = new URLSearchParams(searchParams);
      setSelectedKeys(new Set([]));
      params.delete(`${param}`);
      params.set("page", "1");
      push(`${pathname}?${params.toString()}`);
    }, [searchParams, pathname]);

    useEffect(() => {
      const listStatus = targetParam ? targetParam?.split(",") : [];
      setSelectedKeys(new Set(listStatus));
    }, [targetParam]);

    const handleSearchChange = useCallback((event: any) => {
      event.preventDefault();
      setSearchKeyword(event.target.value);
    }, []);

    const filteredOptions = options.filter((option) =>
      option.label.toLowerCase().includes(searchKeyword.toLowerCase()),
    );

    return (
      <div className="min-w-[182px]">
        <Select
          radius="full"
          selectionMode="multiple"
          // isLoading={isLoading}
          placeholder={`All ${param}`}
          classNames={classNames}
          selectedKeys={selectedKeys}
          selectorIcon={<ArrowDownIcon />}
          onChange={onSelect}
          renderValue={(items) => {
            return (
              <p className="text-base font-medium">
                {items?.length
                  ? `${items?.length} ${param} selected`
                  : `All ${param}`}
              </p>
            );
          }}
          listboxProps={{
            classNames: {
              list: "max-h-[300px] overflow-y-auto overflow-x-hidden",
            },
            topContent: showSearch
              ? ((
                  <div className="">
                    <SearchInput
                      value={searchKeyword}
                      placeholder="Search"
                      onChange={handleSearchChange}
                    />
                  </div>
                ) as any)
              : undefined,

            bottomContent: (
              <div className="h-fit px-3 pb-1">
                <button
                  onClick={onClearAll}
                  className={`!h-7 rounded-md border border-neutral-stroke-bold px-3 text-sm leading-[16px]`}
                >
                  Clear All
                </button>
              </div>
            ),
          }}
        >
          <SelectSection
            classNames={{
              heading: "!pl-0",
            }}
          >
            {filteredOptions.map((option) => (
              <SelectItem
                key={option.key}
                hideSelectedIcon
                textValue={option.label}
                className={`!rounded-[0px] px-4 py-3 data-[hover=true]:!bg-neutral-surface data-[selectable=true]:focus:!bg-neutral-surface`}
              >
                <SelectCheckboxItem
                  checked={selectedKeys.has(option.key)}
                  label={option.label}
                />
              </SelectItem>
            ))}
          </SelectSection>
        </Select>
      </div>
    );
  },
);

interface SearchInputProps {
  className?: string;
  placeholder?: string;
  value: string;
  onChange: (event: any) => void;
}

const SearchInput = memo(
  ({ className, placeholder, value, onChange }: SearchInputProps) => {
    return (
      <div className={cn("w-full px-2 pb-1", className)}>
        <Input
          radius="sm"
          classNames={{
            input: [
              "bg-transparent",
              "text-black/90 dark:text-white/90 font-gilroy font-medium",
              "placeholder:text-default-700/50 dark:placeholder:text-white/60",
            ],
            innerWrapper: "bg-transparent",
            inputWrapper: [
              "bg-white",
              "border",
              "border-neutral-stroke-light",
              "hover:!bg-white",
              "hover:!border-brand-primary",
              "group-data-[focus=true]:bg-white",
              "group-data-[focus=true]:border-brand-primary",
              "!shadow-none",
            ],
          }}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          endContent={<SearchIcon />}
        />
      </div>
    );
  },
);

const SelectCheckboxItem = memo(
  ({ checked, label }: { checked: boolean; label: string }) => {
    return (
      <div className="row items-start gap-3">
        <div>
          {checked ? <CheckedIcon size="20" /> : <UnCheckIcon size="20" />}
        </div>
        <p
          className={`whitespace-break-spaces text-base font-medium uppercase`}
        >
          {label}
        </p>
      </div>
    );
  },
);

export default MyMultipleSelect;
