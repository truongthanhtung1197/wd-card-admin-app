import React, { memo } from "react";

import { Select, SelectItem, SelectProps } from "@nextui-org/react";

import ArrowDownIcon from "../../icons/ArrowDownIcon";

const defaultClassNames = {
  // base: "min-w-fit",
  trigger:
    "bg-white border border-neutral-stroke-light hover:!border-brand-primary active:!border-brand-primary font-gilroy shadow-none",
  label: "text-neutral-element-secondary font-medium text-lg font-gilroy ",
  input: "font-gilroy font-medium text-sm leading-[20px]",
  errorMessage: "text-sm font-medium text-accent-error",
  popoverContent: "!rounded-[8px]",
  listbox: "!px-0",
  // innerWrapper: "!pt-24px",
};

interface MyInputProps extends Omit<SelectProps, "children"> {
  placeholder?: string;
  type?: string;
  className?: string;
  label?: string;
  isClear?: boolean;
  options: any[];
}

function MySelect({
  options,
  classNames,
  defaultSelectedKeys,
  ...restProps
}: MyInputProps) {
  // const [selectedKeys, setSelectedKeys] = React.useState(
  //   new Set(defaultSelectedKeys) as any,
  // );

  return (
    <Select
      aria-label="MySelect"
      classNames={{
        // label: "group-data-[filled=true]:-translate-y-5",
        trigger:
          "bg-white border-1 border-neutral-stroke-light !rounded-[8px] hover:!border-brand-primary active:!border-brand-primary font-gilroy shadow-none",
        listbox: "!px-0 py-2",
      }}
      listboxProps={{
        classNames: {
          list: "max-h-[300px] overflow-y-auto overflow-x-hidden",
        },
        itemClasses: {
          base: [
            "rounded-none !px-4 !py-3 border-y-1 border-transparent",
            "text-default-500",
            "transition-opacity",
            // "data-[hover=true]:text-foreground",
            "data-[hover=true]:!bg-neutral-surface data-[hover=true]:!border-y-1 data-[hover=true]:!border-neutral-stroke-bold",
            "data-[selectable=true]:focus:bg-brand-super-light",
            "data-[pressed=true]:opacity-70",
            // "data-[focus-visible=true]:ring-default-500",
          ],
        },
      }}
      popoverProps={{
        classNames: {
          base: "before:bg-default-200 !p-0",
          content: "!p-0 border-small border-divider bg-background",
        },
      }}
      {...restProps}
      items={options}
      defaultSelectedKeys={defaultSelectedKeys}
      // isInvalid={!!(meta.touched && meta.error)}
      // errorMessage={meta.error}
      // disableSelectorIconRotation
      selectorIcon={
        <div className="absolute right-4">
          <ArrowDownIcon />
        </div>
      }
      renderValue={(items) => {
        return (
          <div className="row">
            {items.map((item: any) => {
              return (
                <div className="" key={item.key}>
                  <p className="font-medium">{item.textValue}</p>
                </div>
              );
            })}
          </div>
        );
      }}
    >
      {(option) => (
        <SelectItem key={option.key} hideSelectedIcon aria-label="MySelectItem">
          {option.label}
        </SelectItem>
      )}
    </Select>
  );
}

export default memo(MySelect);
